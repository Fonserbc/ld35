# Snakoban - 倉庫蛇

A game made for LD53 http://ludumdare.com/compo/ludum-dare-35/?action=preview&uid=16828
and LowRezJam https://itch.io/jam/lowrezjam2016/rate/62392
